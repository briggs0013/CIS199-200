﻿// Program 4
// CIS 200-76
// Grading ID: D2793
// Due: 11/29/16
// This class implements IComparer class to sort parcels in descending order by destination zip.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class DescendingDestinationZipOrder : Comparer<Parcel>
    {
        //Precondition: None
        //Postcondition: Returns positive # if p1 destination zip is less than p2 destination zip
        //               Returns zero if p1 and p2 destination zip are equal
        //               Returns negative # if p1 desination zip is greater than p2 destination zip
        public override int Compare(Parcel p1, Parcel p2)
        {

            if (p1 == null && p2 == null)
                return 0;

            if (p1 == null)
                return -1;

            if (p2 == null)
                return 1;

            return (-1) * p1.DestinationAddress.Zip.CompareTo(p2.DestinationAddress.Zip);


        }



    }
}
