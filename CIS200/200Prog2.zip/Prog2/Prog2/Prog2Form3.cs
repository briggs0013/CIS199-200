﻿//Grading ID: D2793
//Program 2
//Due: 11/1/2016
//CIS200-76
//This class displays letter input box form to create new letter objects that can be displayed with list parcel under report menu
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class letterInputBox : Form
    {

        internal List<Address> comboBoxAddresses; //stored list of addresses pulled from main form

        //Precondtion: list of addresses must contain 2 or more addresses
        //Postcondition: populates comboBoxAddresses variable with list of addresses
        public letterInputBox(List<Address> addressList)
        {
            InitializeComponent();

            comboBoxAddresses = addressList;    
        }

        internal Address originAddress
        {
            //Precondition: origin address must be selected
            //Postcondition: origin address is returned
            get
            {
                return comboBoxAddresses[originAddressComboBox.SelectedIndex];
            }
        }

        internal Address destinationAddress
        {
            //Precondition: destination address must be selected
            //Postcondition: destination address is returned
            get
            {
                return comboBoxAddresses[destinationAddressComboBox.SelectedIndex];
            }
        }

        internal Decimal fixedCost
        {
            //Precondition: fixed cost entered must be a valid decimal
            //Postcondition: fixed csot is returned
            get
            {
                return decimal.Parse(fixedCostTextBox.Text);
            }
        }

        //Precondition: none
        //Postcondition: populates origin address and destination address combobox with name property of comboBoxAddresses
        private void letterInputBox_Load(object sender, EventArgs e)
        {
            foreach (Address a in comboBoxAddresses)
                originAddressComboBox.Items.Add(a.Name);
            foreach (Address a in comboBoxAddresses)
                destinationAddressComboBox.Items.Add(a.Name);
        }
        //Precondition: origin address and destination address cannot be the same and all controls must validate.
        //Postcondition: Sends OK dialog result back to main form to create new address object to be stored in upv1
        private void okButton_Click(object sender, EventArgs e)
        {
            if (originAddressComboBox.Items[originAddressComboBox.SelectedIndex] == destinationAddressComboBox.Items[destinationAddressComboBox.SelectedIndex])
            {
                MessageBox.Show("Please select a destination address different from origin address");

            }
            else if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
        //Precondition: none
        //Postcondition: validates input in origin combobox
        private void originAddressComboBox_Validating(object sender, CancelEventArgs e)
        {
            if ((originAddressComboBox.SelectedIndex == -1))
                e.Cancel = true;

            errorProvider1.SetError(originAddressComboBox, "Select an origin address");
            originAddressComboBox.SelectAll();

        
        }
        //Precondition: none
        //Postcondition: allows user to select another control if input validates
        private void originAddressComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(originAddressComboBox, "");
        }
        //Precondition: None
        //Postcondition: validates input in destination address
        private void destinationAddressComboBox_Validating(object sender, CancelEventArgs e)
        {
            if ((destinationAddressComboBox.SelectedIndex == -1))
                e.Cancel = true;

            errorProvider1.SetError(destinationAddressComboBox, "Select a destination address");
            destinationAddressComboBox.SelectAll();

        }
        //Precondition: None
        //Postcondition: Allows user to select another control if input validates
        private void destinationAddressComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(destinationAddressComboBox, "");
        }
        //Precondition: None
        //Postcondition: validates input in fixed cost textbox
        private void fixedCostTextBox_Validating(object sender, CancelEventArgs e)
        {
            decimal enteredFixedCost;
            if (!decimal.TryParse(fixedCostTextBox.Text, out enteredFixedCost))
                e.Cancel = true;

            errorProvider1.SetError(fixedCostTextBox, "Enter a decimal number");
            fixedCostTextBox.SelectAll();

        }
        //Precondition: None
        //Postcondition: allows user to select another control if input validates
        private void fixedCostTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(fixedCostTextBox, "");

        }
        //Precondition: None
        //Postcondition: Closes letterInputBox form
        private void cancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            this.Close();
        }
    }
}
