﻿//Grading ID: D2793
//Program 2
//Due: 11/1/2016
//CIS200-76
// This class displays address inputbox form to add a new address that can be displayed with list address under report menu
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp

{
    public partial class addressInputBox : Form
    {
        //Precondition: None
        //Postcondition: Initializes form with designed GUI
        public addressInputBox()
        {
            InitializeComponent();
        }

        internal string nameInputValue
        {
            //Precondition:None
            //Postcondition: returns name entered in textbox
            get { return nameTextBox.Text; }}

        internal string addressInputValue
        {
            //Precondition: None
            //Postcondition: returns address entered in textbox
            get { return addressTextBox.Text; }}

        internal string address2InputValue
        {
            //Precondition:None
            //Postcondition: Returns address entered in second address textbox
            get { return address2TextBox.Text; }}

        internal string cityInputValue
        {
            //Precondition: none
            //Postcondition: returns city entered in textbox
            get { return cityTextBox.Text; }}

        internal string stateInputValue
        {
            //Precondition: none
            //Postcondition: returns state selected in combobox as a string
            get { return stateComboBox.Items[stateComboBox.SelectedIndex].ToString(); }}

        internal int zipInputValue
        {
            //Precondition: Zip >= 00000 && Zip <= 99999. Must contain 5 digits.
            //Postcondition: returns zip entered in textbox
            get { return int.Parse(zipTextBox.Text); }}

        //Precondition: all controls must contain input
        //Postcondition: Sends OK dialog result back to main form to create new letter object to be stored in upv1 parcel list.
        private void okButton_Click(object sender, EventArgs e)
        {

            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;      
        }
        //Precondition: None
        //Postcondition: validates input in name textbox
        private void nameTextBox_Validating(object sender, CancelEventArgs e)
        {

            if (nameTextBox.Text == "")
                e.Cancel = true;

            errorProvider1.SetError(nameTextBox, "Enter a name");

            nameTextBox.SelectAll();

        }
        //Precondition: None
        //Postcondition: allows user to select another control if input validates
        private void nameTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(nameTextBox, "");
        }
        //Precondition: None
        //Postcondition: validates input in address textbox
        private void addressTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (addressTextBox.Text == "")
                e.Cancel = true;

            errorProvider1.SetError(addressTextBox, "Select an address");

            addressTextBox.SelectAll();
        }
        //Precondition: None
        //Postcondition: allows user to select another control if input validates
        private void addressTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(addressTextBox, "");
        }
        //Precondition: None
        //Postcondition: validates input in city textbox
        private void cityTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (cityTextBox.Text == "")
                e.Cancel = true;

            errorProvider1.SetError(cityTextBox, "Enter a city");

            cityTextBox.SelectAll();
        }
        //Precondition: None
        //Postcondition: allows user to select another control if input validates
        private void cityTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(cityTextBox, "");
        }
        //Precondition: None
        //Postcondition: validates input in state combobox 
        private void stateComboBox_Validating(object sender, CancelEventArgs e)
        {
            if (stateComboBox.SelectedIndex == -1)
                e.Cancel = true;

            errorProvider1.SetError(stateComboBox, "Select a state");

            stateComboBox.SelectAll();
        }
        //Precondition: None
        //Postcondition: allows user to select another control if input validates
        private void stateComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(stateComboBox, "");
        }
        //Precondition: Zip >= 0 && Zip <= 0. Zip must be 5 digits.
        //Postcondition: validates input in zip textbox
        private void zipTextBox_Validating(object sender, CancelEventArgs e)
        {
            int zipCode; //holds zipcode entered in textbox for validation

            if (zipTextBox.Text.Length != 5)
            {
                e.Cancel = true;
            }
            else if (!int.TryParse(zipTextBox.Text, out zipCode) && (zipCode >= 0 && zipCode <= 99999))
            {
                e.Cancel = true;
            }

            errorProvider1.SetError(zipTextBox, "Select a 5 digit zip code");
            zipTextBox.SelectAll();
        }
        //Precondition: None
        //Postcondition: removes validation message for zipTextBox
        private void zipTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(zipTextBox, "");
        }
        //Precondition:
        //Postcondition: closes addressInputBox form
        private void cancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            this.Close();

        }
    }
}
