﻿//Grading ID: D2793
//Program 2
//Due: 11/1/2016
//CIS200-76
//This class populates the main form with test data. It can be displayed using the report menu to show list of address or parcels. New addresses and letters can be added with insert menu.
//Has a file menu to with an about menu item and exit menu item to close the application. All menu items contain alt shortcuts. 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class Prog2Form : Form
    {

        UserParcelView upv1 = new UserParcelView(); //creates new user parcel view object

        //Precondition: None
        //Postcondition: Displays main form and creates test data
        public Prog2Form()
        {
            InitializeComponent();

            upv1.AddAddress("John Smith", "123 Any St.", "Apt. 45",
                "Louisville", "KY", 40202); // Test Address 1
            upv1.AddAddress("Jane Doe", "987 Main St.", "",
                "Beverly Hills", "CA", 90210); // Test Address 2
            upv1.AddAddress("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            upv1.AddAddress("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            upv1.AddAddress("John Doe", "111 Market St.", "",
                "Jeffersonville", "IN", 47130); // Test Address 5
            upv1.AddAddress("Jane Smith", "55 Hollywood Blvd.", "Apt. 9",
                "Los Angeles", "CA", 90212); // Test Address 6
            upv1.AddAddress("Captain Robert Crunch", "21 Cereal Rd.", "Room 987",
                "Bethesda", "MD", 20810); // Test Address 7
            upv1.AddAddress("Vlad Dracula", "6543 Vampire Way", "Apt. 1",
                "Bloodsucker City", "TN", 37210); // Test Address 8

            upv1.AddLetter(upv1.AddressAt(0), upv1.AddressAt(1), 3.95M);                            // Letter test object
            upv1.AddLetter(upv1.AddressAt(2), upv1.AddressAt(3), 4.25M);                            // Letter test object
            upv1.AddGroundPackage(upv1.AddressAt(4), upv1.AddressAt(5), 14, 10, 5, 12.5);        // Ground test object
            upv1.AddGroundPackage(upv1.AddressAt(6), upv1.AddressAt(7), 8.5, 9.5, 6.5, 2.5);     // Ground test object
            upv1.AddNextDayAirPackage(upv1.AddressAt(0), upv1.AddressAt(2), 25, 15, 15,    // Next Day test object
                85, 7.50M);
            upv1.AddNextDayAirPackage(upv1.AddressAt(2), upv1.AddressAt(4), 9.5, 6.0, 5.5, // Next Day test object
                5.25, 5.25M);
            upv1.AddNextDayAirPackage(upv1.AddressAt(1), upv1.AddressAt(6), 10.5, 6.5, 9.5, // Next Day test object
                15.5, 5.00M);
            upv1.AddTwoDayAirPackage(upv1.AddressAt(3), upv1.AddressAt(6), 46.5, 39.5, 28.0, // Two Day test object
                80.5, TwoDayAirPackage.Delivery.Saver);
            upv1.AddTwoDayAirPackage(upv1.AddressAt(6), upv1.AddressAt(0), 15.0, 9.5, 6.5,   // Two Day test object
                75.5, TwoDayAirPackage.Delivery.Early);
            upv1.AddTwoDayAirPackage(upv1.AddressAt(5), upv1.AddressAt(3), 12.0, 12.0, 6.0,  // Two Day test object
                5.5, TwoDayAirPackage.Delivery.Saver);               
        }

        //Precondition: None
        //Postcondition: Exits application
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //Precondition: None
        //Postcondition: Displays string message in about menu item
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Grading ID: D2793{Environment.NewLine}Program 2{Environment.NewLine}Due: 11/1/2016{Environment.NewLine}Section: CIS200-76{Environment.NewLine}");
        }

        //Precondition: UPV object must contain atleast one address
        //Postcondition: Displays all addresses stored in list of addresses the UPV object contains
        private void listAddressesToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            StringBuilder result = new StringBuilder(); //creates stringbuilder object to hold the display string of each address

            foreach (Address a in upv1.addresses)
                 result.Append($"{a}{Environment.NewLine}{Environment.NewLine}");

            reportDisplay.Text = $"Addresses:{Environment.NewLine}{Environment.NewLine}{result.ToString()}";
        }
        //Precondition: UPV object must contain atleast one address
        //Postcondition: Displays all parcels stored in the list of parcel objects the UPV object contains.
        private void listParcelsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); //creates stringbuilder object to hold display string of each parcel
            decimal totalCost = 0m; //holds running total of each parcel
            

            foreach (Parcel a in upv1.parcels)
                result.Append($"{a}{Environment.NewLine}{Environment.NewLine}");
            for (int count = 0; count < upv1.parcels.Count; count++)
                totalCost += upv1.parcels[count].CalcCost();
            result.Append($"------------------------------------------------------{Environment.NewLine}{Environment.NewLine}Total Cost: {totalCost:C}");

            reportDisplay.Text = $"Parcels:{Environment.NewLine}{Environment.NewLine}{result.ToString()}";

        }
        //Precondition: Name, Address, City, and Zip textboxes must contain input. An item in State text box must be selected. Zip must be between 00000-99999 and exactly 5 digits.
        //Postcondition: Creates new address object and adds it to upv1's addrress list.
        private void addressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addressInputBox addressInputBox = new addressInputBox(); //creates new addressInputBox form
            DialogResult result; //creates DialogResult object to hold OK result to execute if statement if all controls validate successfully

            result = addressInputBox.ShowDialog(); //displays addressInputBox form

            if (result == DialogResult.OK)
            {
                upv1.AddAddress(addressInputBox.nameInputValue, addressInputBox.addressInputValue, addressInputBox.address2InputValue,
                    addressInputBox.cityInputValue, addressInputBox.stateInputValue, addressInputBox.zipInputValue);
            }

        }

      
        //Precondition: origin and destination address combobox must have an item selected. Fixed cost must have a decimal entered. upv1's address list must contain atleast 2 addresses.
        //Postcondition: Creates new letter object and adds it to upv1's parcel list
        private void letterToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (upv1.AddressList.Count >= 2)
            {
                letterInputBox letterInputBox1 = new letterInputBox(upv1.AddressList); //creates new letterInputBox form
                DialogResult result; //creates DialogResult object to hold OK result to execute if statement if all controls validate successfully

                result = letterInputBox1.ShowDialog(); //displays letterInputBox form

                if (result == DialogResult.OK)
                    upv1.AddLetter(letterInputBox1.originAddress, letterInputBox1.destinationAddress, letterInputBox1.fixedCost);
            }
            else
                MessageBox.Show("Please add more than one address to send a letter");
        }
    }
}
