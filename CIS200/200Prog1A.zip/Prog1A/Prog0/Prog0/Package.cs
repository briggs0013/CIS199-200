﻿//D2793
//Program 1A
//Due: 10/11/16
//CIS200-76
//This is an abstract package class derived from parcel that uses origin address, destination address, length, width, height, and weight as its properties

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public abstract class Package : Parcel
{
    //backing fields
    private double _length; //Package's length
    private double _width;  //Package's width
    private double _height; //Package's height
    private double _weight; //Package's weight

    //Precondition: length > 0, width > 0, height >0, weight > 0
    //Postcondition: Package is created with specified values for originAddress, destAddress, length, width, height, weight
    public Package(Address originAddress, Address destAddress, double length, double width, double height, double weight
        ) : base(originAddress, destAddress)
    {
        //use properties to ensure validation occurs
        OriginAddress = originAddress;
        DestinationAddress = destAddress;
        Length = length;
        Width = width;
        Height = height;
        Weight = weight;
    }


    public double Length
    {
        // Precondition:  None
        // Postcondition: The package's length has been returned
        get
        {
            return _length;
        }

        // Precondition:  value > 0
        // Postcondition: The package's length has been set to the
        //                specified value
        set
        {
            if (value > 0)
                _length = value;
            else
                throw new ArgumentOutOfRangeException("Length", value,
                    "Length must be greater than 0");
        }
    }

    public double Width
    {
        // Precondition:  None
        // Postcondition: The package's width has been returned
        get
        {
            return _width;
        }

        // Precondition:  value > 0
        // Postcondition: The package's width has been set to the
        //                specified value
        set
        {
            if (value > 0)
                _width = value;
            else
                throw new ArgumentOutOfRangeException("Width", value,
                    "Width must be greater than 0");
        }
    }

    public double Height
    {
        // Precondition:  None
        // Postcondition: The package's height has been returned
        get
        {
            return _height;
        }

        // Precondition:  value > 0
        // Postcondition: The package's height has been set to the
        //                specified value
        set
        {
            if (value > 0)
                _height = value;
            else
                throw new ArgumentOutOfRangeException("Height", value,
                    "Height must be greater than 0");
        }
    }

    public double Weight
    {
        // Precondition:  None
        // Postcondition: The package's weight has been returned
        get
        {
            return _weight;
        }

        // Precondition:  value > 0
        // Postcondition: The package's weight has been set to the
        //                specified value
        set
        {
            if (value > 0)
                _weight = value;
            else
                throw new ArgumentOutOfRangeException("Weight", value,
                    "Weight must be greater than 0");
        }
    }

    

    //Precondition: None
    //Postcondition: A String with package's data has been returned
    public override string ToString()
    {
        return $"Package\n{base.ToString()}\nLength: {Length}\nWidth: {Width}\nHeight: {Height}\nWeight: {Weight}";
    }
        

    




}

