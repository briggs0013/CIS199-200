﻿//D2793
//Program 1A
//Due: 10/11/16
//CIS200-76
//This is an abstract class for AirPackage's derived from Packages. It uses origin address, destination address, length, width, height, and weight as its properties. It also implements methods
//to determine if the package is heavy or large.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public abstract class AirPackage : Package
{
    //Precondition: length > 0, width > 0, height > 0, weight > 0
    //Postcondition: AirPackage has been created with specified values for originAddress, destinationAddress, length, width, height, weight
    public AirPackage(Address originAddress, Address destinationAddress, double length, double width, double height, double weight)
        : base(originAddress, destinationAddress, length, width, height, weight)
    {
        //ensure validation
        OriginAddress = originAddress;
        DestinationAddress = destinationAddress;
        Length = length;
        Width = width;
        Height = height;
        Weight = weight;
    }

    //Precondtion: None
    //Postcondition: IsHeavy returns true if it is >= 75. It returns false if it is < 75.
    public bool IsHeavy()
    {
        const int WEIGHT_THRESHOLD = 75; //threshold for package to be considered heavy

        if (Weight >= WEIGHT_THRESHOLD)
            return true;
        else
            return false;
    }
    //Precondition: None
    //Postconditon: IsLarge returns true if Length, Width, Height, add up to 100 or more and  returns false if less than 100.
    public bool IsLarge()
    {
        const int DIM_THRESHOLD = 100; //threshold for package to be considered large

        if ((Length + Width + Height) >= DIM_THRESHOLD)
            return true;
        else
            return false;
    }
    //Precondition: None
    //Postcondition: returns String with AirPackage's data 
    public override string ToString()
    {
        return $"Air {base.ToString()}\nHeavy: {IsHeavy()}\nLarge: {IsLarge()}";
    }

}


    
    

