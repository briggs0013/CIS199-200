﻿//D2793
//Program 1A
//Due: 10/11/16
//CIS200-76
//This creates a TwoDayAirPackage derived from AirPackage. It uses origin address, destination address, length, width, height, weight, and delivery type as its properties. It implements a method that
// figures it's cost and if it gets a 10% discount based on delivery type.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class TwoDayAirPackage : AirPackage
{

    public enum Delivery { Early, Saver}; //declare enum with Early and Saver property

    private Delivery _deliveryType; //TwoDayAirPackage's delivery type
    
    //Precondition: length > 0, width > 0, height > 0, weight > 0, deliveryType == Early or deliveryType == Saver
    //Postcondition: TwoDayAirPackage is created with specified value for originAddress, destinationAddress, length, width, height, weight, deliveryType
    public TwoDayAirPackage(Address originAddress, Address destinationAddress, double length, double width, double height, double weight, Delivery deliveryType)
        : base(originAddress, destinationAddress, length, width, height, weight)
    {
        //ensure validation
        OriginAddress = originAddress;
        DestinationAddress = destinationAddress;
        Length = length;
        Width = width;
        Height = height;
        Weight = weight;
        DeliveryType = deliveryType;

    }

    public Delivery DeliveryType
    {

        //Precondtion: None
        //Postcondition: TwoDayAirPackage's delivery type is returned
        get
        {
            return _deliveryType;
        }
        //Precondition: value == Delivery.Early or value == Delivery.Saver
        //Postcondition: TwoDayAirPackage's delivery type is set to specified value
        set
        {
            if ((value == Delivery.Early) || (value == Delivery.Saver))
                _deliveryType = value;
            else
                throw new ArgumentOutOfRangeException("Delivery Type", value, "Please enter Delivery Type Early or Saver");
        }
    }

    //Precondtion: None
    //Postcondition: TwoDayAirPackage's cost is returned 
    public override decimal CalcCost()
    {
        decimal tenPercentDiscount = 1; // % discount to be multipled with base cost
        decimal discountFactor = .90M; //factor for discount if deliveryType is Savor
        double DIM_FACTOR = .25;       //Dimension coefficient in base cost equation
        double WEIGHT_FACTOR = .25;    //Weight coefficient in base cost equation

        decimal baseCost = (decimal)(DIM_FACTOR * (Length + Width + Height) + WEIGHT_FACTOR * (Weight));


        if (DeliveryType == Delivery.Saver)
             tenPercentDiscount = discountFactor;
        
            return baseCost * tenPercentDiscount;
    }

    //Precondition: None
    //Postcondition: returns data fields of TwoDayAirPackage as a String
    public override string ToString()
    {
        return $"____________________\nTwo Day {base.ToString()}\nDelivery Type: {DeliveryType}\n____________________\n";
    }

}

