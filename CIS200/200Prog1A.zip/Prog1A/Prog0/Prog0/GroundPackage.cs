﻿//D2793
//Program 1A
//Due: 10/11/16
//CIS200-76
//This is a class for GroundPackages derived from Package that creates ground packages using origin address, destination address, length, width, height, weight, as its properties. Also implements
//method for calculating cost to ship from origin to destination.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class GroundPackage : Package
{

    //Precondition: length > 0, width > 0, height >0, weight > 0
    //Postcondition: GroundPackage is created with specified values for originAddress, destinationAddress, length, width, height, weight.
    public GroundPackage(Address originAddress, Address destinationAddress, double length, double width, double height, double weight)
        : base(originAddress, destinationAddress, length, width, height, weight)
    {
        //use properties to ensure validation occurs
        OriginAddress = originAddress;
        DestinationAddress = destinationAddress;
        Length = length;
        Width = width;
        Height = height;
        Weight = weight;
    }

    public int ZoneDistance
    {
        // Precondition:  None
        // Postcondition: The ground package's zone distance is returned.
        //                The zone distance is the positive difference between the
        //                first digit of the origin zip code and the first
        //                digit of the destination zip code.
        get
        {
            const int FIRST_DIGIT_FACTOR = 10000; // Denominator to extract 1st digit
            int dist;                             // Calculated zone distance

            dist = Math.Abs((OriginAddress.Zip / FIRST_DIGIT_FACTOR) - (DestinationAddress.Zip / FIRST_DIGIT_FACTOR));

            return dist;
        }
    }
    //Precondition: None
    //Postcondition: The ground package's cost has been returned
    public override decimal CalcCost()
    {
        const double DIM_FACTOR = .20;    //Dimension coefficient in cost equation
        const double WEIGHT_FACTOR = .05; //Weight coefficient in cost equation

        return (decimal)(DIM_FACTOR * (Length + Width + Height) + WEIGHT_FACTOR * (ZoneDistance + 1) * (Weight));
    }

    //Precondition: None
    //Postcondition: A String with the ground package's data has been returned
    public override string ToString()
    {
        return $"____________________\nGround {base.ToString()}\nZoneDistance: {ZoneDistance}\n____________________\n";


    }


}



