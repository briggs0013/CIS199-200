﻿//D2793
//Program 1A
//Due: 10/11/16
//CIS200-76
//This creates a NextDayAirPackage class that is derived from AirPackage. It uses origin address, destination address, length, width, height, weight, and express fee as its properties. It implements
// a method to calculate the cost of the package based on if the NextDayAirPackage is heavy or large.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class NextDayAirPackage : AirPackage
    {
    //backing fields
    private decimal _expressFee; // NextDayAirPackage's express fee
    
    //Precondition: length > 0, width > 0, height > 0, weight > 0, xfee >= 0
    //Postcondition: NextDayAirPackage has been created with specified values for originAddress, destinationAddress, length, width, height, weight, xFee
    public NextDayAirPackage(Address originAddress, Address destinationAddress, double length, double width, double height, double weight, decimal xFee)
        : base(originAddress, destinationAddress, length, width, height, weight)
    {
        //use properties to ensure validation
        OriginAddress = originAddress;
        DestinationAddress = destinationAddress;
        Length = length;
        Width = width;
        Height = height;
        Weight = weight;
        ExpressFee = xFee;
    }


    public decimal ExpressFee
    {
        //Precondition: None
        //Postcondition: NextDayAirPackage's Express Fee has been returned
        get
        {
            return _expressFee;
        }
        //Precondition: value >= 0
        //Postcondition: NextDayAirPackage's express fee has been set to specified value
        private set
        {
            if (value >= 0)
                _expressFee = value;
            else
                throw new ArgumentOutOfRangeException("Express Fee", value,
                    "Express Fee must be greater or equal to 0");


        }
    }
    //Precondition: None
    //Postcondition: Next Day Air Package's cost has been returned with appropriate weight and size fee.
    public override decimal CalcCost()
    {
        const double WEIGHT_FEE_FACTOR = .25; //weight coefficient in weight charge equation
        const double SIZE_FEE_FACTOR = .25; //size coefficient in size charge equation
        const double DIM_FACTOR = .40;    //Dimension coefficient in base cost equation
        const double WEIGHT_FACTOR = .30; //Weight coefficient in base cost equation


        decimal baseCost = (decimal)(DIM_FACTOR * (Length + Width + Height) + WEIGHT_FACTOR * (Weight)) + ExpressFee; //base charge amount
        decimal weightCharge = 0; //extra charge amount if IsHeavy is true
        decimal sizeCharge = 0;   //extra charge amount if IsLarge is true
        
        if (IsHeavy())
            weightCharge = (decimal)(WEIGHT_FEE_FACTOR * (Weight));
        if (IsLarge())
            sizeCharge = (decimal)(SIZE_FEE_FACTOR * (Length + Width + Height));
        return (baseCost + weightCharge + sizeCharge);
    }

    //Precondition: None
    //Postcondition: A String with NextDayAirPackage's data has been returned
    public override string ToString()
    {
        return $"____________________\nNext Day {base.ToString()}\nShipping Cost: {CalcCost().ToString("c")}\nExpress Fee: {ExpressFee.ToString("c")}\n____________________\n";
    }







}

