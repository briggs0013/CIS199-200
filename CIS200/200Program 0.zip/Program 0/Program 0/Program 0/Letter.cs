﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    public class Letter : Parcel
    {
        //backing field
        private decimal _fixedCost; //Letter's fixed cost

        //precondition: fc >= 0
        //postcondition: Letter is created with specified values for origin address, destination address, and fixedcost
        public Letter(Address oAddress, Address dAddress, decimal fC) : base(oAddress, dAddress)
        {
            //use properties to ensure validation occurs
            FixedCost = fC;
        }

        
        public decimal FixedCost
        {
            //precondition: None
            //postcondition: Letter's fixed cost is returned
            get
            { return _fixedCost; }
            //precondition: value >= 0
            //postcondition: Letter's fixed cost is set to specified value
            set
            {
                if (value >= 0)
                    _fixedCost = value;
            }
        }
        //precondition: None
        //postcondition: Letter's cost has been returned
        public override decimal CalcCost()
        {
            return FixedCost;
        }
        //precondition: None
        //postcondition: A String with Parcel's data has been returned
        public override string ToString()
        {
            return $"Origin:\n{OriginAddress}\nDestination:\n{DestinationAddress}\nCost: {FixedCost:C}\n";
        }
    }
}
