﻿/*D2793
 *Program 0
 *Due: Sept 22
 *CIS200-76
 *This program creates Address objects containing name, address1, address2, city, state, and zip codes.It creates Parcel objects composed of two Address objects
 * for destination and origin address. It creates Letter objects derived from Parcel that contains destination and origin Address objects, and the cost. The program
 * will then display the data of Letter objects contained in a list of Parcels.*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    class Program
    {
        //precondition: None
        //postcondition: displays contents of Letter objects
        static void Main(string[] args)
        {
            //created Address objects for test data
            Address firstAddress = new Address("Bob","111 First Dr","Apt #111","Louisville","KY",40258);
            Address secondAddress = new Address("Bill", "5310 Second Dr", "Apt #222", "Louisville", "KY", 40219);
            Address thirdAddress = new Address("Carl", "5235 Third Dr", "Apt #333", "Louisville", "KY", 40207);
            Address fourthAddress = new Address("Steve", "5235 Fourth Dr", "Apt #444", "Louisville", "KY", 40206);
            //created Letter objects for test data
            Letter billsLetter = new Letter(firstAddress, secondAddress, 2);
            Letter carlsLetter = new Letter(firstAddress, thirdAddress, 3);
            Letter stevesLetter = new Letter(firstAddress, fourthAddress, 4);
            //creates list of Parcel objects
            List<Parcel> letters = new List<Parcel>();
            letters.Add(billsLetter);
            letters.Add(carlsLetter);
            letters.Add(stevesLetter);

            //loop to display contents of objects in List
            foreach (var n in letters)
                Console.WriteLine(n);


        }
    }
}
