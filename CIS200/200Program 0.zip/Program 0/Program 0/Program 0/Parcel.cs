﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    public abstract class Parcel
    {
        //backing field
        private Address _originAddress; //Parcel's origin address
        private Address _destinationAddress; //Parcel's destination address

        //precondition: None
        //postcondition: Parcel is created with specified origin address and destination address
        public Parcel(Address oAddress, Address dAddress)
        {
            //use properties to ensure validation will occur
            OriginAddress = oAddress;
            DestinationAddress = dAddress;
        }

        public Address OriginAddress
        {
            //precondition: None
            //postcondition: Parcel's origin address is returned
            get
            {
                return _originAddress;
            }
            //precondition: None
            //postcondition: Parcel's origin address is set to specified value
            set
            {
                _originAddress = value;
            }
        }

        public Address DestinationAddress
        {
            //precondition: None
            //postcondition: Parcel's destination address is returned
            get
            {
                return _destinationAddress;
            }
            //precondition: None
            //postcondition: Parcel's destination address is set to specified value
            set
            {
                _destinationAddress = value;
            }
        }
        //precondition: None
        //postcondition: Parcel's cost has been returned
        public abstract decimal CalcCost();

        //precondition: None
        //postcondition: A String with Parcel's data has been returned
        public override string ToString()
        {
            return $"Origin Address: {OriginAddress}\nDestination Address: {DestinationAddress}\n{CalcCost():C}" ;
        }



        




    }
}
