﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    public class Address
    {
        //backing fields
        private string _name; // Address's name
        private string _address1; //Address's first address
        private string _address2; //Address's second address
        private string _city; //Address's city
        private string _state; //Address's state
        private int _zip; //Address's zipcode

        //validation values
        public const int MAX_ZIP = 99999; //Maximum zip code value
        public const int MIN_ZIP = 00000; //Minimum zip code value
 
        
        //precondition: MIN_ZIP <= z <= MAX_ZIP
        //postcondition: Address is created with specified values for name, Address1, Address2, City, State, Zip
        public Address( string n, string a1, string a2, string c, string s, int z)
        {
            //use properties to ensure validation occurs
            Name = n;
            Address1 = a1;
            Address2 = a2;
            City = c;
            State = s;
            Zip = z;
        }

        
        public string Name
        {
            //precondition: None
            //postcondition: Address's name has been returned
            get
            {
                return _name;
            }
            //precondition: None
            //postcondition: Address's name has been set to specified value
            set
            {
                _name = value;
            }
        }

         public string Address1
        {
            //precondition: None
            //postcondition: Address's address1 has been returned
            get
            {
                return _address1;
            }
            //precondition: None
            //postcondition: Address's address1 has been set to specified value
            set
            {
                _address1 = value;
            }
        }

        public string Address2
        {
            //precondition: None
            //postcondition: Address's address2 has been returned
            get
            {
                return _address2;
            }
            //precondition: None
            //postcondition: Address's address2 has been set to specified value
            set
            {
                _address2 = value;
            }
        }

        public string City
        {
            //precondition: None
            //postcondition: Address's city has been returned
            get
            {
                return _city;
            }
            //precondition: None
            //postcondition: Address's city has been set to specified value
            set
            {
                _city = value;
            }
        }

        public string State
        {
            //precondition: None
            //postcondition: Address's state has been returned
            get
            {
                return _state;
            }
            //precondition: None
            //postcondition: Address's state has been set to specified value
            set
            {
                _state = value;
            }
        }

        public int Zip
        {
            //precondition: None
            //postcondition: Address's zip code has been returned
            get
            {
                return _zip;
            }
            //preconditon: MIN_ZIP <= valie <= MAX_ZIP
            //postcondition: Address's zip code has been set to specified value
            set
            {
                if ((value >= MIN_ZIP) && (value <= MAX_ZIP))
                    _zip = value;
                else
                    throw new ArgumentOutOfRangeException("Zip", value, "Zip must be >= 0 and <= 99999");
            }
        }
        //precondition: None
        //postcondition: A String with Address's date has been returned 
        public override string ToString()
        {
            return $"{Name}\n{Address1}\n{Address2}\n{City}, {State} {Zip:D5}";
        }





    
    }
}
