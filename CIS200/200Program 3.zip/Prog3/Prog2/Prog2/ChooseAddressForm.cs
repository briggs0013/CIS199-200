﻿//D2793
//Program 3
//Due: 11/15/16
//CIS200-76
//This class allows the user to edit an existing address object.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class chooseAddressForm : Form
    {

        private List<Address> addressList; //list of addresses used to fill combo box
    
        //Precondition: List of address is populated
        //Postcondition: Form's GUI is prepared for dispaly
        public chooseAddressForm(List<Address> addresses)
        {
            InitializeComponent();
            addressList = addresses;
        }

        internal int EditAddressIndex
        {
            //Precondition: User has selected from editAddressComboBox
            //Postcondition: The index of selected address to be editted is returned
            get
            {
                return editAddressComboBox.SelectedIndex;
            }
        }
        //Precondition: User clicked on okButton
        //Postcondition: If invalid field on dialog errorProvider pops up. Else return OK and close form
        private void okButton_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
        //Precondition: Focus shifting from editAddressComboBox sender is editAddressComboBox
        //Postcondition: If no address is selected, focus remains and error provider highlights the field
        private void editAddressComboBox_Validating(object sender, CancelEventArgs e)
        {
            if (editAddressComboBox.SelectedIndex == -1) 
            {
                e.Cancel = true;
                errorProvider1.SetError(editAddressComboBox, "Must choose an address to edit!");
            }
        }
        //Precondition: editAddressComboBox validates
        //Postcondition: error provider cleared and allowed to change
        private void editAddressComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(editAddressComboBox, "");
        }
        // Precondition:  User pressed on cancelButton
        // Postcondition: Form closes
        private void cancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // Was it a left-click?
                this.DialogResult = DialogResult.Cancel;
        }
        //Precondition: None
        //Postcondition: list of addresses is used to populate editAddressComboBox
        private void ChooseAddressForm_Load(object sender, EventArgs e)
        {
            foreach (Address a in addressList)
            {
                editAddressComboBox.Items.Add(a.Name);  
            }
        }
    }
}
