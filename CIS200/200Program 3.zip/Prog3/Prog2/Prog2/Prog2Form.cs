﻿//D2793
//Program 3
//Due: 11/15/16
//CIS200-76
//This program allows you to create address and parcels that will be stored in lists. 
//A report of each list can be displayed. The address can be editted and the program's data can be saved and reopened.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Text;
using System.Windows.Forms;

namespace UPVApp
{
    [Serializable]
    public partial class Prog2Form : Form
    {

        private BinaryFormatter formatter = new BinaryFormatter(); //variable to serialize data
        private FileStream output; //variable used to save data
        private FileStream input; //varaible used to load data

        private UserParcelView upv; // The UserParcelView
        

        // Precondition:  None
        // Postcondition: The form's GUI is prepared for display. A few test addresses are
        //                added to the list of addresses
        public Prog2Form()
        {
            InitializeComponent();

            upv = new UserParcelView();

        }

        // Precondition:  File, About menu item activated
        // Postcondition: Information about author displayed in dialog box
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string NL = Environment.NewLine; // Newline shorthand

            MessageBox.Show($"Program 2{NL}By: Andrew L. Wright{NL}CIS 200{NL}Fall 2016",
                "About Program 2");
        }

        // Precondition:  File, Exit menu item activated
        // Postcondition: The application is exited
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Precondition:  Insert, Address menu item activated
        // Postcondition: The Address dialog box is displayed. If data entered
        //                are OK, an Address is created and added to the list
        //                of addresses
        private void addressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddressForm addressForm = new AddressForm();    // The address dialog box form
            DialogResult result = addressForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                try
                {
                    upv.AddAddress(addressForm.AddressName, addressForm.Address1,
                        addressForm.Address2, addressForm.City, addressForm.State,
                        int.Parse(addressForm.ZipText)); // Use form's properties to create address
                }
                catch (FormatException) // This should never happen if form validation works!
                {
                    MessageBox.Show("Problem with Address Validation!", "Validation Error");
                }
            }

            addressForm.Dispose(); // Best practice for dialog boxes
        }

        // Precondition:  Report, List Addresses menu item activated
        // Postcondition: The list of addresses is displayed in the addressResultsTxt
        //                text box
        private void listAddressesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // Holds text as report being built
                                                        // StringBuilder more efficient than String
            string NL = Environment.NewLine;            // Newline shorthand

            result.Append("Addresses:");
            result.Append(NL); // Remember, \n doesn't always work in GUIs
            result.Append(NL);

            foreach (Address a in upv.AddressList)
            {
                result.Append(a.ToString());
                result.Append(NL);
                result.Append("------------------------------");
                result.Append(NL);
            }

            reportTxt.Text = result.ToString();

            // Put cursor at start of report
            reportTxt.Focus();
            reportTxt.SelectionStart = 0;
            reportTxt.SelectionLength = 0;
        }

        // Precondition:  Insert, Letter menu item activated
        // Postcondition: The Letter dialog box is displayed. If data entered
        //                are OK, a Letter is created and added to the list
        //                of parcels
        private void letterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LetterForm letterForm; // The letter dialog box form
            DialogResult result;   // The result of showing form as dialog

            if (upv.AddressCount < LetterForm.MIN_ADDRESSES) // Make sure we have enough addresses
            {
                MessageBox.Show("Need " + LetterForm.MIN_ADDRESSES + " addresses to create letter!",
                    "Addresses Error");
                return;
            }

            letterForm = new LetterForm(upv.AddressList); // Send list of addresses
            result = letterForm.ShowDialog();

            if (result == DialogResult.OK) // Only add if OK
            {
                try
                {
                    // For this to work, LetterForm's combo boxes need to be in same
                    // order as upv's AddressList
                    upv.AddLetter(upv.AddressAt(letterForm.OriginAddressIndex),
                        upv.AddressAt(letterForm.DestinationAddressIndex),
                        decimal.Parse(letterForm.FixedCostText)); // Letter to be inserted
                }
                catch (FormatException) // This should never happen if form validation works!
                {
                    MessageBox.Show("Problem with Letter Validation!", "Validation Error");
                }
            }

            letterForm.Dispose(); // Best practice for dialog boxes
        }

        // Precondition:  Report, List Parcels menu item activated
        // Postcondition: The list of parcels is displayed in the parcelResultsTxt
        //                text box
        private void listParcelsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // Holds text as report being built
                                                        // StringBuilder more efficient than String
            decimal totalCost = 0;                      // Running total of parcel shipping costs
            string NL = Environment.NewLine;            // Newline shorthand

            result.Append("Parcels:");
            result.Append(NL); // Remember, \n doesn't always work in GUIs
            result.Append(NL);

            foreach (Parcel p in upv.ParcelList)
            {
                result.Append(p.ToString());
                result.Append(NL);
                result.Append("------------------------------");
                result.Append(NL);
                totalCost += p.CalcCost();
            }

            result.Append(NL);
            result.Append($"Total Cost: {totalCost:C}");

            reportTxt.Text = result.ToString();

            // Put cursor at start of report
            reportTxt.Focus();
            reportTxt.SelectionStart = 0;
            reportTxt.SelectionLength = 0;
        }
        //Precondition: must have UPV object to save
        //Postcondition: saves UPV object
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

            DialogResult result; //The result of showing form as dialog
            string fileName; // name of file

            using (SaveFileDialog fileChooser = new SaveFileDialog())
            {
                fileChooser.CheckFileExists = false;

                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName;
            }

            if (result == DialogResult.OK)
            {
                if (fileName == string.Empty)
                    MessageBox.Show("Invalid File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                {
                  try
                    {
                        
                        output = new FileStream(fileName, FileMode.Create, FileAccess.Write);

                        formatter.Serialize(output, upv);
                    }
                    catch (IOException)
                    {
                        MessageBox.Show("Error opening file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                     finally
                    {
                        if (output != null)
                            output.Close();
                    }           
                }
            }

            

        }
        //Precondition: must have save file to open
        //Postcondition: Loads UPV object from save file
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result; //The result of showing form as dialog
            string fileName; //name of file

            using (OpenFileDialog fileChooser = new OpenFileDialog())
            {
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName;
            }

            if (result == DialogResult.OK)
            {
                if (fileName == string.Empty)
                    MessageBox.Show("Invalid File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                {
                    try
                    {
                        input = new FileStream(fileName, FileMode.Open, FileAccess.Read);

                        upv = (UserParcelView)formatter.Deserialize(input);
                    }
                    catch (IOException)
                    {
                        MessageBox.Show("Error opening file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        if (input != null)
                            input.Close();
                    }
                }
            }    
        }
        //Precondition: must have address to edit
        //Postcondition: Edits selected address
        private void addressToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            chooseAddressForm chooseAddressForm = new chooseAddressForm(upv.AddressList); //creates chooseAddressForm with address list argument
            DialogResult result = chooseAddressForm.ShowDialog(); //loads chooseAddressFrom as modal dialog


            if (result == DialogResult.OK)
            {
                
                AddressForm addressForm = new AddressForm(); //creates address form
                //populates fields of address form
                addressForm.AddressName = upv.AddressAt(chooseAddressForm.EditAddressIndex).Name;
                addressForm.Address1 = upv.AddressAt(chooseAddressForm.EditAddressIndex).Address1;
                addressForm.Address2 = upv.AddressAt(chooseAddressForm.EditAddressIndex).Address2;
                addressForm.City = upv.AddressAt(chooseAddressForm.EditAddressIndex).City;
                addressForm.State = upv.AddressAt(chooseAddressForm.EditAddressIndex).State;
                addressForm.ZipText = upv.AddressAt(chooseAddressForm.EditAddressIndex).Zip.ToString();
                DialogResult result2 = addressForm.ShowDialog(); //loads address form as modal dialog

                if (result == DialogResult.OK)
                {
                    //edits selected upv address with updated information entered in corresponding field of address form
                    upv.AddressAt(chooseAddressForm.EditAddressIndex).Name = addressForm.AddressName;
                    upv.AddressAt(chooseAddressForm.EditAddressIndex).Address1 = addressForm.Address1;
                    upv.AddressAt(chooseAddressForm.EditAddressIndex).Address2 = addressForm.Address2;
                    upv.AddressAt(chooseAddressForm.EditAddressIndex).City = addressForm.City;
                    upv.AddressAt(chooseAddressForm.EditAddressIndex).State = addressForm.State;
                    upv.AddressAt(chooseAddressForm.EditAddressIndex).Zip = int.Parse(addressForm.ZipText);
                }                                   
            }

                
                

        }
    }
}