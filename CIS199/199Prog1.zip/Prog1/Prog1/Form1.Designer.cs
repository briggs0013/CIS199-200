﻿namespace Prog1
{
    partial class PaintSuite
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sqFtLbl = new System.Windows.Forms.Label();
            this.coatsLbl = new System.Windows.Forms.Label();
            this.gallonPriceLbl = new System.Windows.Forms.Label();
            this.sqftTxtBox = new System.Windows.Forms.TextBox();
            this.coatsTxtBox = new System.Windows.Forms.TextBox();
            this.gallonPriceTxtBox = new System.Windows.Forms.TextBox();
            this.totalSqFtLabel = new System.Windows.Forms.Label();
            this.gallonLabel = new System.Windows.Forms.Label();
            this.hoursLabel = new System.Windows.Forms.Label();
            this.paintCostLabel = new System.Windows.Forms.Label();
            this.laborCostLabel = new System.Windows.Forms.Label();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.calculateBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // sqFtLbl
            // 
            this.sqFtLbl.AutoSize = true;
            this.sqFtLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sqFtLbl.Location = new System.Drawing.Point(44, 24);
            this.sqFtLbl.Name = "sqFtLbl";
            this.sqFtLbl.Size = new System.Drawing.Size(184, 13);
            this.sqFtLbl.TabIndex = 0;
            this.sqFtLbl.Text = "Enter # of sq. ft. to be painted:";
            // 
            // coatsLbl
            // 
            this.coatsLbl.AutoSize = true;
            this.coatsLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coatsLbl.Location = new System.Drawing.Point(46, 54);
            this.coatsLbl.Name = "coatsLbl";
            this.coatsLbl.Size = new System.Drawing.Size(182, 13);
            this.coatsLbl.TabIndex = 1;
            this.coatsLbl.Text = "Enter # of coats to be painted:";
            // 
            // gallonPriceLbl
            // 
            this.gallonPriceLbl.AutoSize = true;
            this.gallonPriceLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gallonPriceLbl.Location = new System.Drawing.Point(44, 88);
            this.gallonPriceLbl.Name = "gallonPriceLbl";
            this.gallonPriceLbl.Size = new System.Drawing.Size(184, 26);
            this.gallonPriceLbl.TabIndex = 2;
            this.gallonPriceLbl.Text = "Enter price per gallon of paint: \r\n(Do not include dollar sign)\r\n";
            // 
            // sqftTxtBox
            // 
            this.sqftTxtBox.Location = new System.Drawing.Point(293, 21);
            this.sqftTxtBox.Name = "sqftTxtBox";
            this.sqftTxtBox.Size = new System.Drawing.Size(100, 20);
            this.sqftTxtBox.TabIndex = 3;
            // 
            // coatsTxtBox
            // 
            this.coatsTxtBox.Location = new System.Drawing.Point(293, 51);
            this.coatsTxtBox.Name = "coatsTxtBox";
            this.coatsTxtBox.Size = new System.Drawing.Size(100, 20);
            this.coatsTxtBox.TabIndex = 4;
            // 
            // gallonPriceTxtBox
            // 
            this.gallonPriceTxtBox.Location = new System.Drawing.Point(293, 85);
            this.gallonPriceTxtBox.Name = "gallonPriceTxtBox";
            this.gallonPriceTxtBox.Size = new System.Drawing.Size(100, 20);
            this.gallonPriceTxtBox.TabIndex = 5;
            // 
            // totalSqFtLabel
            // 
            this.totalSqFtLabel.Location = new System.Drawing.Point(293, 151);
            this.totalSqFtLabel.Name = "totalSqFtLabel";
            this.totalSqFtLabel.Size = new System.Drawing.Size(100, 23);
            this.totalSqFtLabel.TabIndex = 6;
            // 
            // gallonLabel
            // 
            this.gallonLabel.Location = new System.Drawing.Point(293, 174);
            this.gallonLabel.Name = "gallonLabel";
            this.gallonLabel.Size = new System.Drawing.Size(100, 23);
            this.gallonLabel.TabIndex = 7;
            // 
            // hoursLabel
            // 
            this.hoursLabel.Location = new System.Drawing.Point(293, 197);
            this.hoursLabel.Name = "hoursLabel";
            this.hoursLabel.Size = new System.Drawing.Size(100, 23);
            this.hoursLabel.TabIndex = 8;
            // 
            // paintCostLabel
            // 
            this.paintCostLabel.Location = new System.Drawing.Point(293, 220);
            this.paintCostLabel.Name = "paintCostLabel";
            this.paintCostLabel.Size = new System.Drawing.Size(100, 23);
            this.paintCostLabel.TabIndex = 9;
            // 
            // laborCostLabel
            // 
            this.laborCostLabel.Location = new System.Drawing.Point(293, 243);
            this.laborCostLabel.Name = "laborCostLabel";
            this.laborCostLabel.Size = new System.Drawing.Size(100, 23);
            this.laborCostLabel.TabIndex = 10;
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCostLabel.Location = new System.Drawing.Point(293, 266);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(100, 23);
            this.totalCostLabel.TabIndex = 11;
            this.totalCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.totalCostLabel.Visible = false;
            // 
            // calculateBtn
            // 
            this.calculateBtn.Location = new System.Drawing.Point(47, 193);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Size = new System.Drawing.Size(75, 23);
            this.calculateBtn.TabIndex = 12;
            this.calculateBtn.Text = "Calculate";
            this.calculateBtn.UseVisualStyleBackColor = true;
            this.calculateBtn.Click += new System.EventHandler(this.calculateBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.Location = new System.Drawing.Point(153, 193);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 23);
            this.clearBtn.TabIndex = 13;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(100, 262);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(75, 23);
            this.exitBtn.TabIndex = 14;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // PaintSuite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(437, 327);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.calculateBtn);
            this.Controls.Add(this.totalCostLabel);
            this.Controls.Add(this.laborCostLabel);
            this.Controls.Add(this.paintCostLabel);
            this.Controls.Add(this.hoursLabel);
            this.Controls.Add(this.gallonLabel);
            this.Controls.Add(this.totalSqFtLabel);
            this.Controls.Add(this.gallonPriceTxtBox);
            this.Controls.Add(this.coatsTxtBox);
            this.Controls.Add(this.sqftTxtBox);
            this.Controls.Add(this.gallonPriceLbl);
            this.Controls.Add(this.coatsLbl);
            this.Controls.Add(this.sqFtLbl);
            this.Name = "PaintSuite";
            this.Text = "Paint Suite";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label sqFtLbl;
        private System.Windows.Forms.Label coatsLbl;
        private System.Windows.Forms.Label gallonPriceLbl;
        private System.Windows.Forms.TextBox sqftTxtBox;
        private System.Windows.Forms.TextBox coatsTxtBox;
        private System.Windows.Forms.TextBox gallonPriceTxtBox;
        private System.Windows.Forms.Label totalSqFtLabel;
        private System.Windows.Forms.Label gallonLabel;
        private System.Windows.Forms.Label hoursLabel;
        private System.Windows.Forms.Label paintCostLabel;
        private System.Windows.Forms.Label laborCostLabel;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.Button calculateBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button exitBtn;
    }
}

