﻿/* Bradley Riggs
 * Program 1
 * Due 2/14/2016
 * CIS199 - 75
 * This program will tell you the total square feet to paint, gallons of paint needed, hours of labor, cost of paint, cost of labor, and total cost of labor & paint.
 * This information is displayed by entering the square footage of the walls to be painted, the number of coats you would like to apply and the cost of the paint.*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog1
{
    public partial class PaintSuite : Form
    {
        public PaintSuite()
        {
            InitializeComponent();
        }

        private void calculateBtn_Click(object sender, EventArgs e)
        {
           
           
                const int SquareFeet = 325; //represents square footage used for 1 gallon of paint and 8 hours of labor
                const decimal CostOfLabor = 10.50m; //represents cost of labor charged by company
                const int LaborHours = 8; //represents amount of labor required to paint 325 square feet of wall space with 1 gallon of paint
                decimal CeilingGallons; //amount of paint that needs to be purchased
                decimal CalculatedGallons; //amount of paint to actually be used
                decimal SqFtPainted; //square feet to be painted entered by user
                decimal CoatsOfPaint; //coats of paint used entered by user
                decimal PricePerGallon; //price of paint per gallon entered by user
                decimal TotalPaintCost; //total cost of paint
                decimal TotalLaborCost; //total cost of labor
                decimal TotalCost; //total cost of labor and paint
                double TotalSqFt; //total square feet to be painted after number of coats has been factored in
                double TotalLaborHours; //total hours the job will take


                PricePerGallon = decimal.Parse(gallonPriceTxtBox.Text); //get price per gallon of paint
                CoatsOfPaint = decimal.Parse(coatsTxtBox.Text); //get number of coats of paint to be used
                SqFtPainted = decimal.Parse(sqftTxtBox.Text); //get square footage to be painted

                TotalSqFt = (double)SqFtPainted * (double)CoatsOfPaint; //calculate total square feet to be painted
                CalculatedGallons = (decimal)TotalSqFt / (decimal)SquareFeet; //calculate gallons of paint to be used
                CeilingGallons = Math.Ceiling(CalculatedGallons); //calculate amount of paint to be purchased
                TotalLaborHours = TotalSqFt / SquareFeet * LaborHours; //calculate total hours of labor job will take
                TotalPaintCost = PricePerGallon * CeilingGallons; //calculate total cost of paint
                TotalLaborCost = CostOfLabor * (decimal)TotalLaborHours; //calculate total cost of labor
                TotalCost = TotalLaborCost + TotalPaintCost; //calculate total cost of labor and paint



                totalSqFtLabel.Text = TotalSqFt.ToString("n0") + " " + "Total sq. ft."; //display total square feet to be painted
                gallonLabel.Text = CeilingGallons.ToString() + " " + "gal"; //display gallons of paint to be purchased
                hoursLabel.Text = TotalLaborHours.ToString("n1") + " " + "hours"; //display total hours of labor job will take
                paintCostLabel.Text = TotalPaintCost.ToString("c") + " " + "paint"; //display total cost of paint
                laborCostLabel.Text = TotalLaborCost.ToString("c") + " " + "labor"; //display total cost of labor
                totalCostLabel.Text = TotalCost.ToString("c") + " " + "total"; //display total cost of labor and paint

                totalCostLabel.Visible = true; //display border in total label
          
            
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close(); //exits application
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            //clears all output labels and makes total cost border invisible
            totalSqFtLabel.Text = ""; 
            gallonLabel.Text = "";
            hoursLabel.Text = "";
            paintCostLabel.Text = "";
            laborCostLabel.Text = "";
            totalCostLabel.Text = "";
            totalCostLabel.Visible = false;

            //clears all numbers entered into textboxes
            coatsTxtBox.Text = "";
            gallonPriceTxtBox.Text = "";
            sqftTxtBox.Text = "";
        }
    }
}
