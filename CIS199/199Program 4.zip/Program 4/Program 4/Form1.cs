﻿/*Brad Riggs
 *Program 4
 *Due 4/24/2016
 *CIS 199-75
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_4
{
    public partial class Form1 : Form
    {
        List<GroundPackage> packageList = new List<GroundPackage>(); //create list of ground packages

        public Form1()
        {
            InitializeComponent();
        }
        //Precondition: none
        //Postcondition: creates new ground package object and adds to parallel list and listbox with calculated cost. Stores input user enters in object properties.
        private void addPackageBtn_Click(object sender, EventArgs e)
        {
            int originZip; // origin zip input
            int destinationZip; //destination zipcode input
            double length; //length input
            double width; // width input
            double height; //height input
            double weight; //weight input

            //validate input
            if (int.TryParse(originTextBox.Text, out originZip))
            {
                if (originZip >= 0 && originZip <= 99999) 
                {
                    if (int.TryParse(destTextBox.Text, out destinationZip))
                    {
                        if (destinationZip >= 0 && destinationZip <= 99999)
                        {
                            if (double.TryParse(lengthTextBox.Text, out length))
                            {
                                if (length > 0)
                                {
                                    if (double.TryParse(widthTextBox.Text, out width))
                                    {
                                        if (width > 0)
                                        {
                                            if (double.TryParse(heightTextBox.Text, out height))
                                            {
                                                if (height > 0)
                                                {
                                                    if (double.TryParse(weightTextBox.Text, out weight))
                                                    {
                                                        if (weight > 0)
                                                        {
                                                            //create new ground package if input is valid
                                                            GroundPackage package = new GroundPackage(originZip, destinationZip, length, width, height, weight);
                                                            packageList.Add(package); // add new package to list
                                                            packageListBox.Items.Add(package.CalcCost().ToString("c")); //add cost of package shipment to parallel spot in listbox

                                                        }
                                                            //error messages for invalid input
                                                        else
                                                            MessageBox.Show("Please enter weight greater than 0"); 
                                                    }
                                                    else
                                                        MessageBox.Show("Please enter valid weight");
                                                }
                                                else
                                                    MessageBox.Show("Please enter height greater than 0");
                                            }                                                                                                  
                                            else
                                            MessageBox.Show("Please enter valid height");
                                        }
                                        else
                                            MessageBox.Show("Please enter width greater than 0");

                                    }
                                    else
                                        MessageBox.Show("Please enter valid width");
                                }
                                else
                                    MessageBox.Show("Please enter length greater than 0");
                            }
                            else
                                MessageBox.Show("Please enter valid length");
                        }
                        else
                            MessageBox.Show("Please enter destination zipcode between 0-99999");
                    }
                    else
                        MessageBox.Show("Please enter valid destination zipcode");
                }
                else
                    MessageBox.Show("Please enter origin zipcode between 0-99999");
            }
            else
                MessageBox.Show("Please enter valid origin zipcode");

 
        }
        //Precondition: none
        //Postcondition: displays properties of selected ground package in a messagebox.
        private void detailsBtn_Click(object sender, EventArgs e)
        {
            int index = packageListBox.SelectedIndex; // variable for selected index
            if (index == -1)//verifies that ground package is selected
                MessageBox.Show("Please select a package");
            else
                MessageBox.Show(packageList[index].ToString()); // display properties for selected package
        }
        //Precondition: none
        //Postcondition: changes destination zipcode to 40292 and updates cost in the listbox
        private void sendToUOFLBtn_Click(object sender, EventArgs e)
        {
            int index = packageListBox.SelectedIndex; //variable for selected index
            int uoflZip = 40292; //uofl zip
            
            if (index == -1) //verify ground package is selected
                MessageBox.Show("Please select a package");
            else
            {
                packageList[index].DestinationZip = uoflZip;  //changes DestinationZip property      
                packageListBox.Items[index] = packageList[index].CalcCost().ToString("c"); //updates cost of shipment after destination zip changes
                MessageBox.Show("The destination zip code has been changed to 40292, the price has changed to: " + packageListBox.Items[index]); //displays and confirms zip change and new price
            }
        }
        //Precondition: none
        //Postcondition: changes origin zipcode to 40292 and calculates new cost
        private void sendFromUOFLBtn_Click(object sender, EventArgs e)
        {
            int index = packageListBox.SelectedIndex; //variable for selected index
            int uoflZip = 40292; //uofl zip

            if (index == -1)//verifies that ground package is selected
                MessageBox.Show("Please select a package");
            else
            {
                packageList[index].OriginZip = uoflZip;//changes OriginZip property
                packageListBox.Items[index] = packageList[index].CalcCost().ToString("c"); //updates cost of shipment after origin zip changes
                MessageBox.Show("The origin zip code has been changed to 40292, the price has changed to: " + packageListBox.Items[index]); //displays and confirms zip change and new price
            }
        }

    }
}
