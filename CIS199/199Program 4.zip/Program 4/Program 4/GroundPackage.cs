﻿/*Brad Riggs
 *Program 4
 *Due 4/24/2016
 *CIS 199-75
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    public class GroundPackage
    {
        private int _originZip; // >= 0 and <= 99999
        private int _destinationZip; // >= 0 and <= 99999
        private double _length; // > 0
        private double _width; // > 0
        private double _height; // > 0 
        private double _weight; // > 0

        //Precondtion: 0 <= OZ <= 99999
        //             0 <= DZ <= 99999
        //             L > 0
        //             Wi > 0
        //             H > 0
        //             We > 0
        //Postcondition: The GroundPackage object must be initialized with valid OriginZip, DestinationZip, Length, Width, Height, Weight
        public GroundPackage(int OZ, int DZ, double L, double Wi, double H, double We)
        {
            OriginZip = OZ; //set OriginZip property
            DestinationZip = DZ; // set DestinationZip property
            Length = L; // set Length Property
            Width = Wi; // set Width property
            Height = H; // set Height property
            Weight = We; // set Weight property
        }

        public int OriginZip
        {
            //Precondition: none
            //Postcondition: The Origin Zipcode has been returned
            get
                {return _originZip;}
            //Precondition: 0 <= value <= 99999
            //Postcondition: originZip has been set to specified value
            set
            {
                if (value >= 0 && value <= 99999)
                    _originZip = value;
            }
        }
        public int DestinationZip
        {
            //Precondition: none
            //Postcondition: The destinationZip has been returned
            get
            { return _destinationZip; }
            //Precondition: 0 <= value <= 99999
            //Postcondition: destinationZip has been set to specified value
            set
            {
                if (value >= 0 && value <= 99999)
                    _destinationZip = value;
            }
        }
        public double Length
        {
            //Precondition: none
            //Postcondition: The Length has been returned
            get
            { return _length; }
            //Precondtion: value > 0
            //Postcondition: Length has been set to specified value
            set
            {
                if (value > 0)
                    _length = value;
            }
        }
        public double Width
        {
            //Precondition: none
            //Postcondition: The width has been returned
            get
            { return _width; }
            //Precondtion: value > 0
            //Postcondition: Width has been set to specified value
            set
            {
                if (value > 0)
                    _width = value;
            }
        }
        public double Height
        {
            //Precondition: none
            //Postcondition: The height has been returned
            get
            { return _height; }
            //Precondtion: value > 0
            //Postcondition: Height has been set to specified value
            set
            {
                if (value > 0)
                    _height = value;
            }
        }
        public double Weight
        {
            //Precondition: none
            //Postcondition: The weight has been returned
            get
            { return _weight; }
            //Precondtion: value > 0
            //Postcondition: Weight has been set to specified value
            set
            {
                if (value > 0)
                     _weight = value;
            }

            
        }
        public int ZoneDistance
        {
            //Precondition: none
            //Postcondition: calculates and returns zonedistance
            get
            {return Math.Abs((OriginZip/10000) - (DestinationZip/10000));}
        }
        //Precondition: groundpackage must have valid properties
        //Postcondition: calculates and returns cost of package
        public double CalcCost()
        {
            return .20 * (Length + Width + Height) + .5 * (ZoneDistance + 1) * (Weight);
        }
        //precondition: none
        //postcondition: a string is returned displaying each property on its own line in a messagebox 
        public override string ToString()
        {
            return "Origin Zip: " + OriginZip.ToString("D5") + System.Environment.NewLine
                + "Destination Zip: " + DestinationZip.ToString("D5") + System.Environment.NewLine
                + "Length: " + Length.ToString() + " inches" + System.Environment.NewLine
                + "Width: " + Width.ToString() + " inches" + System.Environment.NewLine
                + "Height: " + Height.ToString() + " inches" + System.Environment.NewLine
                + "Weight: " + Weight.ToString() + " pounds" + System.Environment.NewLine;
        }

       
    }
}
