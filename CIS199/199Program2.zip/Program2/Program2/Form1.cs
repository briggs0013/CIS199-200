﻿/*Brad Riggs
 *Program 2
 *Due 3/6/16
 *CIS 199-75
 *This program will determine earliest registration date by last name and class standing
 */
 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class registrationForm : Form
    {
        public registrationForm()
        {
            InitializeComponent();
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            try //used to catch exception from not entering a last name
            {
                const int SENIOR = 4; //used to determine case for senior in switch statement
                const int SOPHOMORE = 2; //used to determine case for sophomore in switch statement
                const int JUNIOR = 3; //used to determine case for junior in switch statement
                const int FRESHMAN = 1; //used to determine case for freshman in switch statement
                double seniorRequirement = 90; //minimum credits to be classified a senior
                double juniorRequirement = 60; //minimum credits to be classified a junior
                double sophomoreRequirement = 30; //minimum credits to be classified a sophomore
                double enteredCreditHours; //holds credit hours entered by user
                string lastName; //holds last name entered by user
                int calculatedClassStanding = 0; //holds senior, junior, sophomore, or freshman value to be tested in switch statement
                char firstLetterLastName; //holds the first character entered in last name

                //gets first letter from last name entered into lastNameTextBox and forces it to lower case for case insensitive testing.
                lastName = lastNameTextBox.Text.ToString();
                firstLetterLastName = char.ToLower(lastName[0]);


                //parse credit hours input. Requires user to enter valid number of credit hours
                if (double.TryParse(completedHoursTextBox.Text, out enteredCreditHours))
                {
                    //requires credit hours entered to be greater than 0
                    if (enteredCreditHours >= 0)
                    {
                        //determines Class Standing and value is assigned to variable to determine which case to use for the switch statement below
                        if (enteredCreditHours >= seniorRequirement)
                            calculatedClassStanding = SENIOR;
                        else if (enteredCreditHours >= juniorRequirement)
                            calculatedClassStanding = JUNIOR;
                        else if (enteredCreditHours >= sophomoreRequirement)
                            calculatedClassStanding = SOPHOMORE;
                        else
                            calculatedClassStanding = FRESHMAN;
                    }
                    else
                        MessageBox.Show("Enter a value greater than 0.");  //message displayed when number is less than 0             
                }
                else
                    MessageBox.Show("Must enter a number that is greater than 0.");

                //multiple-alternative decision structure to determine and display Class Standing and Registration Time/Date in a messagebox.
                switch (calculatedClassStanding)
                {
                    case FRESHMAN: //displays registration time/date for freshman
                        if (firstLetterLastName >= 'w')
                            MessageBox.Show("Freshman, Earliest Registration Date: April 6th at 11:30am");
                        else if (firstLetterLastName >= 't')
                            MessageBox.Show("Freshman, Earliest Registration Date: April 6th at 10:00am");
                        else if (firstLetterLastName >= 'r')
                            MessageBox.Show("Freshman, Earliest Registration Date: April 6th at 8:30am");
                        else if (firstLetterLastName >= 'p')
                            MessageBox.Show("Freshman, Earliest Registration Date: April 5th at 4:00pm");
                        else if (firstLetterLastName >= 'm')
                            MessageBox.Show("Freshman, Earliest Registration Date: April 5th at 2:00pm");
                        else if (firstLetterLastName >= 'j')
                            MessageBox.Show("Freshman, Earliest Registration Date: April 5th at 11:30am");
                        else if (firstLetterLastName >= 'g')
                            MessageBox.Show("Freshman, Earliest Registration Date: April 5th at 10:00am");
                        else if (firstLetterLastName >= 'e')
                            MessageBox.Show("Freshman, Earliest Registration Date: April 5th at 8:30am");
                        else if (firstLetterLastName >= 'c')
                            MessageBox.Show("Freshman, Earliest Registration Date: April 6th at 4:00pm");
                        else if (firstLetterLastName >= 'a')
                            MessageBox.Show("Freshman, Earliest Registration Date: April 6th at 2:00pm");
                        else
                            MessageBox.Show("Freshman, Please contact Registrar's Office for registration time. (Office Hours Monday-Friday 9:00am to 5:00pm, Phone Number: 502-852-6522)"); //prompts user to call office if name does not start with a-z
                        break;
                    case SOPHOMORE: //displays registration time/date for sophomore
                        if (firstLetterLastName >= 'w')
                            MessageBox.Show("Sophomore, Earliest Registration Date: April 4th at 11:30am");
                        else if (firstLetterLastName >= 't')
                            MessageBox.Show("Sophomore, Earliest Registration Date: April 4th at 10:00am");
                        else if (firstLetterLastName >= 'r')
                            MessageBox.Show("Sophomore, Earliest Registration Date: April 4th at 8:30am");
                        else if (firstLetterLastName >= 'p')
                            MessageBox.Show("Sophomore, Earliest Registration Date: April 1th at 4:00pm");
                        else if (firstLetterLastName >= 'm')
                            MessageBox.Show("Sophomore, Earliest Registration Date: April 1th at 2:00pm");
                        else if (firstLetterLastName >= 'j')
                            MessageBox.Show("Sophomore, Earliest Registration Date: April 1th at 11:30am");
                        else if (firstLetterLastName >= 'g')
                            MessageBox.Show("Sophomore, Earliest Registration Date: April 1th at 10:00am");
                        else if (firstLetterLastName >= 'e')
                            MessageBox.Show("Sophomore, Earliest Registration Date: April 1th at 8:30am");
                        else if (firstLetterLastName >= 'c')
                            MessageBox.Show("Sophomore, Earliest Registration Date: April 4th at 4:00pm");
                        else if (firstLetterLastName >= 'a')
                            MessageBox.Show("Sophomore, Earliest Registration Date: April 4th at 2:00pm");
                        else
                            MessageBox.Show("Sophomore, Please contact Registrar's Office for registration time. (Office Hours Monday-Friday 9:00am to 5:00pm, Phone Number: 502-852-6522)"); //prompts user to call office if name does not start with a-z
                        break;
                    case JUNIOR: //display registration time/date for junior
                        if (firstLetterLastName >= 't')
                            MessageBox.Show("Junior, Earliest Registration Date: March 31st at 2:00pm");
                        else if (firstLetterLastName >= 'p')
                            MessageBox.Show("Junior, Earliest Registration Date: March 31st at 11:30am");
                        else if (firstLetterLastName >= 'j')
                            MessageBox.Show("Junior, Earliest Registration Date: March 31st at 10:00am");
                        else if (firstLetterLastName >= 'e')
                            MessageBox.Show("Junior, Earliest Registration Date: March 31st at 8:30am");
                        else if (firstLetterLastName >= 'a')
                            MessageBox.Show("Junior, Earliest Registration Date: March 31st at 4:00pm");
                        else
                            MessageBox.Show("Junior, Please contact Registrar's Office for registration time. (Office Hours Monday-Friday 9:00am to 5:00pm, Phone Number: 502-852-6522)"); //prompts user to call office if name does not start with a-z
                        break;
                    case SENIOR: //display registration time/date for senior
                        if (firstLetterLastName >= 't')
                            MessageBox.Show("Senior, Earliest Registration Date: March 30th at 2:00pm");
                        else if (firstLetterLastName >= 'p')
                            MessageBox.Show("Senior, Earliest Registration Date: March 30th at 11:30am");
                        else if (firstLetterLastName >= 'j')
                            MessageBox.Show("Senior, Earliest Registration Date: March 30th at 10:00am");
                        else if (firstLetterLastName >= 'e')
                            MessageBox.Show("Senior, Earliest Registration Date: March 30th at 8:30am");
                        else if (firstLetterLastName >= 'a')
                            MessageBox.Show("Senior, Earliest Registration Date: March 30th at 4:00pm");
                        else
                            MessageBox.Show("Senior, Please contact Registrar's Office for registration time. (Office Hours Monday-Friday 9:00am to 5:00pm, Phone Number: 502-852-6522)");//prompts user to call office if name does not start with a-z
                        break;
                }
            }
            catch //displays message box for user to enter last name
            {
                MessageBox.Show("Please enter first and last name");
            }
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
